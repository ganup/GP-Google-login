=== GP Google login ===
Contributors: ganeshpaygude,clarionwpdeveloper
Tags: google login,loginwith google,social login,accountwith google.
Requires at least: 3.2
Tested up to: 4.4.1
Stable tag: 1.0
License: GPLv2

A simple login with google account in WordPress

== Description ==

A simple login with google account in WordPress

Major features in GP Google login  include:

*A simple login with google account in WordPress
*Auto login of existing user after authentication.
*Auto user create if new user after authentication.


== Installation ==


1. Upload the plugin files to the '/wp-content/plugins/' directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Create google app for your web application 
4.Insert your cient ID and secret 
//You can get it from : https://console.developers.google.com/
5.Add client_id,client_secret,redirect_uri in plugin setting option.
6.use shortcode to display in widget or in page content '[GP_google_button]'.


== Frequently Asked Questions ==


== Screenshots ==

1. Screenshot-1 


== Changelog ==

= 1.0 =
* current version 1.0 


== Upgrade Notice ==

= 1.0 =
currently no upgrades sections

== Arbitrary section ==


== A brief Markdown Example ==

