<?php
/*
  Plugin Name: GP Google login.
  Plugin URI: 
  Description: A simple login with google account in WordPress.
  Version: 1.0
  Author: Ganesh Paygude 
  License: GPLv2 or later
 */
session_start();
require_once ('libraries/Google/autoload.php');

/* Setup the plugin. */
add_action( 'plugins_loaded', 'Gp_google_login_setup' );
/* Register plugin activation hook. */
register_activation_hook(__FILE__, 'Gp_google_login_activation');
/* Register plugin activation hook. */
register_deactivation_hook( __FILE__, 'Gp_google_login_deactivation' );

function Gp_google_login_activation() {
	global $wpdb;
	global $jal_db_version;
    $options_array = array(        
        'Gp_google_login_client_id' => '',
        'Gp_google_login_client_secret' => '',
		'Gp_google_login_redirect_uri' => '',
    );
    if (get_option('Gp_google_login_options') !== false) {
        update_option('Gp_google_login_options', $options_array);
    } else {
        add_option('Gp_google_login_options', $options_array);
    }	
}
/**
 * Flush permalinks on plugin deactivation.
 */
function Gp_google_login_deactivation() {
    flush_rewrite_rules();
	global $wpdb;
	  //Delete any options that's stored also?
	  delete_option('Gp_google_login_options');
	 
}
function Gp_google_login_setup() {

/* Get the plugin directory URI. */
	define( 'GP_GOOGLE_LOGIN_PLUGIN_URI', trailingslashit( plugin_dir_url( __FILE__ ) ) );	
}
function Gp_google_login_wp_enqueue_scripts() {    
	
	wp_enqueue_style( 'Gp_google_login_stylesheet', GP_GOOGLE_LOGIN_PLUGIN_URI. 'css/gp_google_login_style.css');
}
add_action( 'wp_head', 'Gp_google_login_wp_enqueue_scripts' );

function Gpgl_callback() {    
}
function Gp_google_login_client_id_callback() {
    $options = get_option('Gp_google_login_options');
    echo "<input class='regular-text ltr' name='Gp_google_login_options[Gp_google_login_client_id]' id='Gp_google_login_client_id' type='text' value='{$options['Gp_google_login_client_id']}'/>";
}
function Gp_google_login_client_secret_callback() {
    $options = get_option('Gp_google_login_options');
    echo "<input class='regular-text ltr' name='Gp_google_login_options[Gp_google_login_client_secret]' id='Gp_google_login_client_secret' type='text' value='{$options['Gp_google_login_client_secret']}'/>";
}
function Gp_google_login_redirect_uri_callback() {
    $options = get_option('Gp_google_login_options');
    echo "<input class='regular-text ltr' name='Gp_google_login_options[Gp_google_login_redirect_uri]' id='Gp_google_login_redirect_uri' type='text' value='{$options['Gp_google_login_redirect_uri']}'/>";
}

function Gp_google_login_settings_and_fields() {

    register_setting(
            'Gp_google_login_options', 'Gp_google_login_options'
    );

    add_settings_section(
            'Gp_google_login_main_section', __('Plugin Settings'), 'Gpgl_callback', __FILE__
    );
	add_settings_field(
            'Gp_google_login_client_id', __('Google App Client ID:'), 'Gp_google_login_client_id_callback', __FILE__, 'Gp_google_login_main_section', array('label_for' => 'Gp_google_login_client_id')
    );
	add_settings_field(
            'Gp_google_login_client_secret', __('Google App client serect:'), 'Gp_google_login_client_secret_callback', __FILE__, 'Gp_google_login_main_section', array('label_for' => 'Gp_google_login_client_secret')
    );	
	
     add_settings_field(
            'Gp_google_login_redirect_uri', __('Google Login Redirect URI:'), 'Gp_google_login_redirect_uri_callback', __FILE__, 'Gp_google_login_main_section', array('label_for' => 'Gp_google_login_redirect_uri')
    );    
}
add_action('admin_init', 'Gp_google_login_settings_and_fields');

function Gp_google_login_options_init() {
    add_options_page(
            __('GP Google Login'), __('GP Google Login'), 'administrator', __FILE__, 'Gp_google_login_options_page'
    );
}
add_action('admin_menu', 'Gp_google_login_options_init');

function Gp_google_login_options_page() {
    ?>
    <div class="wrap">
        <h2><?php _e('Gp Google Login Settings') ?></h2>
        <form method="post" action="options.php" enctype="multipart/form-data">
            <?php
            settings_fields('Gp_google_login_options');
            do_settings_sections(__FILE__);
            submit_button();
            ?>
        </form>
    </div>
    <?php
}
class Gp_google_api_app_details{
	function __construct() {
		$options = get_option('Gp_google_login_options');
		$this->client_id = $options['Gp_google_login_client_id'];
		$this->client_secret = $options['Gp_google_login_client_secret'];
		$this->redirect_uri = $options['Gp_google_login_redirect_uri'];
			
		}	
}
add_action('wp_logout','gp_google_login_clear_session');
function gp_google_login_clear_session(){
	unset($_SESSION['access_token']);
	wp_redirect( home_url() );
	
}
add_action('init', 'Gp_goole_login');
function Gp_goole_login($google_login_button=false){

if (isset($_GET['logout'])) {
	unset($_SESSION['access_token']);	
}
// Google Service call
$api_service_deatils = new Gp_google_api_app_details();
$client = new Google_Client();
$client->setClientId($api_service_deatils->client_id);
$client->setClientSecret($api_service_deatils->client_secret);
$client->setRedirectUri($api_service_deatils->redirect_uri);
$client->addScope("email");
$client->addScope("profile");

$service = new Google_Service_Oauth2($client);

		if (isset($_GET['code'])) {			
			if (strval($_SESSION['state']) !== strval($_GET['state'])) {
				
			  die("The session state ({$_SESSION['state']}) didn't match the state parameter ({$_GET['state']})");
			}
			try {
				$client->authenticate($_GET['code']);
				$_SESSION['access_token'] = $client->getAccessToken();
			} catch (Exception $e) {
				  unset($_SESSION['access_token']);			  
				  print "<p class='error'>Invalid API Credentials!<p>\n";			  
				  wp_redirect( site_url() );
				  exit();
			}
		}

		if (isset($_SESSION['access_token']) && $_SESSION['access_token']) {
			$client->setAccessToken($_SESSION['access_token']);
		} else {
			$authUrl = $client->createAuthUrl();
		}
//if token then grab data
	  if ($client->getAccessToken()) {
		  
		//Check if user exists and/or create
		if (isset($_GET['code'])) {
		  try {
			$user = $service->userinfo->get();
		  } catch (Exception $e) {
			  unset($_SESSION['access_token']);
			  print "<p class='error'>Invalid Google Account!<p>\n";
			  wp_redirect( site_url() );
			  exit();
		  }
		  //Get or Create User			
			$user = $service->userinfo->get();					
			$users = get_user_by( 'email', $user->email );
			$user_id = $users->ID;	
			$gp_user_name=$user->name;
			$gp_user_name_arr=explode(" ",$gp_user_name);
			$gp_user_name=$gp_user_name_arr[0];			
			$gp_user_fisrtname=sanitize_user( $gp_user_name_arr[0] );
			$gp_user_lastname=sanitize_user( $gp_user_name_arr[1] );
			$gp_user_name=sanitize_user( $gp_user_name );
			$gp_user_name=str_replace(array(" ","."),"",$gp_user_name);
			$gp_user_name_check = username_exists( $gp_user_name );
			
		  if($user_id){	
		  
					$users = get_user_by( 'id', $user_id ); 
					$users = get_user_by('login',$users->user_login);		
					update_user_meta( $user_id, 'googleplus_access_token', $user->id );
					update_user_meta( $user_id, 'googleplus_profile_img', $user->picture );
					update_user_meta( $user_id, 'gp_display_name', $user->name );
					update_user_meta( $user_id, 'first_name', $gp_user_fisrtname );
					update_user_meta( $user_id, 'last_name', $gp_user_lastname );
		  }		
		 else{					
					
					
					if ( $gp_user_name_check ) { 
					$gp_user_name=$gp_user_name_arr[1];
					$gp_user_name=sanitize_user( $gp_user_name );
					$gp_user_name=str_replace(array(" ","."),"",$gp_user_name);
					$gp_user_name_check = username_exists( $gp_user_name );
					}
					if ( $gp_user_name_check ) { 
					$gp_user_name=$user->name;;
					$gp_user_name=sanitize_user( $gp_user_name );
					$gp_user_name=str_replace(array(" ","."),"",$gp_user_name);
					$gp_user_name_check = username_exists( $gp_user_name );
					}
					if ( $gp_user_name_check ) { 
					$gp_user_name=$gp_user_name_arr[0];
					$gp_user_name=sanitize_user( $gp_user_name );
					$gp_user_name=str_replace(array(" ","."),"",$gp_user_name);
					$gp_user_name=$gp_user_name.rand(100, 999);
					$gp_user_name_check = username_exists( $gp_user_name );
					}
					if ( !$gp_user_name_check and email_exists($user->email) == false ) {
						$random_password = wp_generate_password( $length=12, $include_standard_special_chars=false );
						$user_id = wp_create_user( $gp_user_name, $random_password, $user->email );
						$users = get_user_by( 'id', $user_id );							
						update_user_meta( $user_id, 'googleplus_access_token', $user->id );
						update_user_meta( $user_id, 'googleplus_profile_img', $user->picture );
						update_user_meta( $user_id, 'gp_display_name', $user->name );
						update_user_meta( $user_id, 'first_name', $gp_user_fisrtname );
						update_user_meta( $user_id, 'last_name', $gp_user_lastname );
					}			
		  }
		  //login user and redirect
			 wp_set_current_user( $user_id, $users->user_login );
			 wp_set_auth_cookie( $user_id, false, is_ssl() );
			 wp_redirect( site_url() );
			  exit();
		  
		}
		if (isset($_GET['code'])) {
		  $_SESSION['access_token'] = $client->getAccessToken();
		}
	  }
	  
	   //display Google Login button
	  if ($google_login_button==true) {		 
		
		if(is_user_logged_in()){
			 $user_id = get_current_user_id();
			 $googleplus_profile_img = get_user_meta ( $user_id,'googleplus_profile_img', true );
			 $gp_display_name = get_user_meta ( $user_id,'gp_display_name', true );
			 echo '<div class="Gp_login_details_wrap">';
			 echo '<img src="'.$googleplus_profile_img.'" />';
			 echo 'Hello, '.$gp_display_name;
			 echo '</div><div class="clear"></div>';
		}else{
			if (!$client->getAccessToken()) {			
				if($_SESSION['state']){
				  $state=$_SESSION['state'];
				}else{
				  $state = mt_rand();
				}
				$client->setState($state);
				$_SESSION['state'] = $state;
				$authUrl = $client->createAuthUrl();
				
				if($api_service_deatils->client_id ){			
					echo "<div class='gplus-login' style='padding:5px 0;'><a class='login' href='".$authUrl."'><img title='Google+ Connect!' src='".plugins_url('/images/google-login-button.png',__FILE__)."'></a></div>";
				}
			}			
		}	
		
	  }
}
add_action('login_form', 'Gp_gplus_login_button_add');
function Gp_gplus_login_button_add(){
	Gp_goole_login(true);
}
//short code
add_filter('widget_text', 'do_shortcode');
add_shortcode( 'GP_google_button', 'Gp_gplus_login_button_add_shortcode' );
function Gp_gplus_login_button_add_shortcode( $atts ) {
	ob_start();
	Gp_goole_login(true);
	$output = ob_get_contents();;
	ob_end_clean();
	return $output;
}